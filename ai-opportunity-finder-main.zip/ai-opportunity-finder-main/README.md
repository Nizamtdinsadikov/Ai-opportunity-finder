# The AI Opportunity Finder

### 7 Claude Code skills that find $300K+ in hidden AI opportunities inside your company

We ran this playbook for a major sports franchise and found **4,000+ hours/year of wasted effort** across 6 departments in 2 weeks. 15 interviews. 27 opportunities identified. 7 prioritized. Executive sign-off in 24 hours.

This is the same Discovery Sprint methodology we use on $10-15K consulting engagements - packaged as Claude Code skills you can run yourself.

---

## How to Install (2 minutes)

### Step 1: Download

**Option A - Git Clone:**
```bash
git clone https://github.com/nickstellarstreamai/ai-opportunity-finder.git
```

**Option B - Download ZIP:**

Click the green **Code** button above → **Download ZIP** → Unzip the folder.

### Step 2: Copy the skills into your project

```bash
# From inside your project directory:
cp -r /path/to/ai-opportunity-finder/skills/ .claude/skills/
```

If you don't have a `.claude/skills/` directory yet, this command creates it.

### Step 3: Run your first scan

Open Claude Code in your project directory and type:

```
/opportunity-scanner
```

It'll ask about your company, industry, and pain points - then generate your first set of AI opportunity hypotheses.

That's it. You're running.

---

## What's Inside

| # | Skill | What It Does |
|---|-------|-------------|
| 1 | `/opportunity-scanner` | Generate AI opportunity hypotheses based on your industry and pain points |
| 2 | `/workflow-audit` | Audit a specific process to find automation opportunities |
| 3 | `/interview-builder` | Create stakeholder interview guides with role-specific questions |
| 4 | `/insight-analyzer` | Process interview transcripts into structured findings |
| 5 | `/department-synthesizer` | Aggregate findings into department-level synthesis with quantified impact |
| 6 | `/priority-ranker` | Prioritize opportunities by Impact x Feasibility |
| 7 | `/executive-briefing` | Build a 7-slide executive presentation with talking points |

Plus: templates, anonymized examples from a real engagement, and the full methodology guide.

---

## The Workflow

```
/opportunity-scanner        ← Start here. Generate hypotheses.
        │
   /workflow-audit          ← Deep-dive a specific process.
        │
   /interview-builder       ← Build interview guides for stakeholders.
        │
     [Conduct Interviews]   ← You do this part.
        │
   /insight-analyzer        ← Process each transcript into findings.
        │
   /department-synthesizer  ← Roll up findings by department.
        │
   /priority-ranker         ← Rank all opportunities. Kill the weak ones.
        │
   /executive-briefing      ← Build the presentation for leadership.
```

Each skill's output feeds the next. Start at the top.

---

## What You'll Have When You're Done

- **3-5 testable hypotheses** about where AI can help your organization
- **Structured findings** from every stakeholder interview
- **Department-level syntheses** with quantified impact (hours/year, $)
- **A ranked priority matrix** with your top 5-7 opportunities
- **A 7-slide executive briefing** ready to present to leadership

All built from your own data, your people's own words, and a proven prioritization framework.

---

## Who This Is For

- **Business owners** who know they should "do something with AI" but don't know where to start
- **Operations leaders** drowning in manual processes who need to build the case for automation
- **Internal AI leads** who need a framework for identifying and prioritizing opportunities
- **Consultants** who want a repeatable discovery methodology

**Company size sweet spot:** 50-500 employees. Big enough to have real process inefficiencies, small enough that you can actually change things.

---

## See It In Action

Check the [`examples/`](examples/) directory for anonymized output from a real engagement:

- [Hypothesis Generation](examples/example-hypothesis-output.md) - Opportunity scanning for a 100-person organization
- [Interview Findings](examples/example-findings-output.md) - Structured findings from a VP of Performance interview
- [Department Synthesis](examples/example-synthesis-output.md) - 4 interviews synthesized into one department view
- [Priority Matrix](examples/example-priority-matrix.md) - 27 opportunities narrowed to 7 priorities

---

## The Methodology

These skills are built on the Discovery Sprint methodology developed across 47+ client engagements in 11 industries. Three core principles:

1. **Hypothesis-driven, not comprehensive.** Start with theories. Validate through interviews. Don't try to document everything.
2. **Show, don't tell.** Quantified findings with direct quotes from your own people create action. Abstract recommendations create debate.
3. **Ruthless prioritization.** You'll find more opportunities than you can pursue. The skill is knowing which 3-5 actually matter.

Full methodology: [METHODOLOGY.md](METHODOLOGY.md)

---

## What These Skills Can (and Can't) Do

**What they do well:**
- Generate structured hypotheses based on industry patterns
- Create professional interview guides
- Process transcripts into actionable findings
- Synthesize and quantify impact by department
- Prioritize with a rigorous framework
- Build executive presentation outlines

**Where you'll hit the ceiling:**
- **Cross-department pattern detection** - The skills work department-by-department. The deepest insights come from seeing patterns across 10+ departments simultaneously (like discovering that one problem costs 4,000+ hours/year across the whole org).
- **Working prototypes** - The executive briefing has placeholder demo slides. Building prototypes with real data that make executives lean forward is a different skill.
- **Implementation** - Finding opportunities is step 1. Building AI solutions, training your team, and driving adoption so it actually sticks is step 2.

---

## Want Expert Help?

These skills give you the methodology. We bring 47+ engagements worth of pattern recognition.

If you've run through the workflow and want a professional Discovery Sprint - or you've found opportunities and need a team to build them - let's talk.

**Book a call with Nick:** [calendly.com/nick-morningside/intro-meeting-with-nick-morningside-ai](https://calendly.com/nick-morningside/intro-meeting-with-nick-morningside-ai)

**Learn more:** [morningside.ai](https://morningside.ai)

---

## Contributing

Found a bug? Have a suggestion? Open an issue or PR.

## License

MIT - Use these skills however you want. If they help you find opportunities, we'd love to hear about it.

---

*Built by [Morningside AI](https://morningside.ai) - AI Strategy & Transformation for Growing Companies*
