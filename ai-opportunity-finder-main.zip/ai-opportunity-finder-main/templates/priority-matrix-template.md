# AI Opportunity Priority Matrix: [Company Name]
**Date:** [Date]
**Departments Analyzed:** [List]
**Total Interviews:** [Number]
**Opportunities Identified:** [Total]
**Priority Opportunities:** [Top 5-7]

---

## Executive Summary

[3-5 sentences]

**Key Numbers:**
- Total addressable hours/year: [X]
- Estimated annual cost: $[Y]
- Opportunities identified: [Total]
- Priority opportunities: [Number]

---

## Priority Matrix

| Rank | Opportunity | Workstream | Impact | Feasibility | Hours Saved | Est. Value |
|------|-------------|-----------|--------|-------------|-------------|------------|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

---

## Quick Wins (Weeks 1-4)

### 1. [Name]
- **What:** [One sentence]
- **Who benefits:** [Roles]
- **Expected result:** [Measurable outcome]
- **Timeline:** [Weeks]

---

## Strategic Initiatives (Months 2-6)

### 1. [Name]
- **What:** [One sentence]
- **Who benefits:** [Roles]
- **Expected result:** [Measurable outcome]
- **Timeline:** [Months]
- **Investment required:** [Scope]

---

## Cross-Cutting Themes

| Theme | Departments Affected | Impact |
|-------|---------------------|--------|
| | | |

---

## Implementation Roadmap

### Immediate (Weeks 1-4)
| Action | Owner | Dependencies |
|--------|-------|-------------|
| | | |

### Near-Term (Months 2-3)
| Project | Owner | Investment |
|---------|-------|------------|
| | | |

### Strategic (Months 4-6)
| Initiative | Sponsor | Investment |
|------------|---------|------------|
| | | |

---
Built with the AI Opportunity Finder by Morningside AI
