# Executive Briefing: AI Discovery Findings
**Company:** [Company Name]
**Presented by:** [Your name]
**Date:** [Date]
**Duration:** 20 minutes
**Audience:** [Who's in the room]

---

## Slide 1: Opening Hook (2 min)

**Headline:** [Compelling statistic or quote]

> "[Most powerful quote from interviews]"
> — [Role], [Department]

**Supporting stat:** [Biggest quantified finding]

---

## Slide 2: The Mandate (1 min)

**What We Set Out To Do:**
- Interviewed [X] people across [Y] departments
- Identified where AI/automation can move the needle
- Prioritized by impact and feasibility

---

## Slide 3: Key Findings (3 min)

1. **[Finding 1]:** [Quantified insight]
2. **[Finding 2]:** [Quantified insight]
3. **[Finding 3]:** [Quantified insight]
4. **[Finding 4]:** [Cross-cutting pattern]
5. **[Finding 5]:** [Most surprising finding]

---

## Slide 4: Priority Opportunities (3 min)

**Quick Wins:**
- [Opportunity 1] — [Impact]
- [Opportunity 2] — [Impact]

**Strategic:**
- [Opportunity 3] — [Impact]
- [Opportunity 4] — [Impact]

**Total addressable impact:** [Hours/year | $Value]

---

## Slide 5: Deep Dive #1 (3 min)

**[Opportunity Name]**

**The Problem:** [30-second context]
**The Solution:** [Demo, mockup, or before/after]
**The Impact:** [Quantified benefit]

---

## Slide 6: Deep Dive #2 (3 min)

**[Opportunity Name]**

**The Problem:** [30-second context]
**The Solution:** [Demo, mockup, or before/after]
**The Impact:** [Quantified benefit]

---

## Slide 7: Path Forward (3 min)

**Immediate (Weeks 1-4):**
- [Quick Win with owner]

**Near-Term (Months 1-3):**
- [Project]

**Strategic (Months 3-6):**
- [Initiative]

**Call to Action:** [Specific next step]

---

## Q&A Prep

| Question | Prepared Answer |
|----------|----------------|
| "How long to build?" | |
| "What does it cost?" | |
| "What systems needed?" | |
| "Who owns this?" | |
| "What's the ROI?" | |

---
Built with the AI Opportunity Finder by Morningside AI
