# AI Opportunity Hypotheses: [Company Name]
**Generated:** [Date]
**Industry:** [Industry]
**Company Size:** [Employees]
**Focus Areas:** [Departments/Functions]

## Executive Summary

[2-3 sentences on the most promising opportunity areas based on industry patterns and stated challenges]

---

## Hypothesis 1: [Title]

**Department:** [Department]
**Pattern Match:** [Which known pattern this maps to]

**We believe that** [department/function] spends [estimated time] on [activity]
**which could be** [automated/augmented] using [AI approach],
**resulting in** [estimated impact: hours saved, cost reduction, quality improvement].

**Why we think this:**
- [Industry benchmark or pattern evidence]
- [Connection to stated challenge]

**To validate, interview:**
- [Role 1] — Ask: "[Specific question]"
- [Role 2] — Ask: "[Specific question]"

**Data to collect:**
- [Metric 1]
- [Metric 2]

**Confidence:** [High/Medium/Low]
**Potential Impact:** [Range]
**Quick Win Potential:** [Yes/No — and why]

---

## Hypothesis 2: [Title]

[Same structure as above]

---

## Hypothesis 3: [Title]

[Same structure as above]

---

## Recommended Interview Order

### Phase 1: Executives (Days 1-2)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|
| | | |

### Phase 2: Frontline Workers (Days 3-7)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|
| | | |

### Phase 3: Back to Executives (Days 8-10)
| Purpose | What to Validate |
|---------|-----------------|
| | |

---

## Patterns to Watch For

| Pattern | Description | Likelihood |
|---------|-------------|------------|
| | | |

---

## Next Steps

1. `/interview-builder` — Create tailored interview guides
2. `/workflow-audit` — Deep-dive into highest-confidence hypothesis
3. After interviews: `/insight-analyzer` — Process findings

---
Built with the AI Opportunity Finder by Morningside AI
