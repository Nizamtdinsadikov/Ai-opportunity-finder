# Interview Findings: [Full Name] - [Role/Title]
**Department:** [Department]
**Company:** [Company Name]
**Interview Date:** [Date]
**Duration:** [Minutes]
**Processed:** [Date]

---

## Context

**Role Summary:** [2-3 sentences]

**Key Responsibilities:**
- [Responsibility 1]
- [Responsibility 2]

**Systems/Tools Used Daily:**
- [System 1] — [Purpose]
- [System 2] — [Purpose]

---

## Pain Points Identified

### Pain Point 1: [Title]

| Dimension | Detail |
|-----------|--------|
| **Description** | |
| **Time Impact** | |
| **Frequency** | |
| **People Affected** | |
| **Business Impact** | |
| **Quote** | "" |
| **Automation Potential** | [High/Medium/Low] |

### Pain Point 2: [Title]

| Dimension | Detail |
|-----------|--------|
| **Description** | |
| **Time Impact** | |
| **Frequency** | |
| **People Affected** | |
| **Business Impact** | |
| **Quote** | "" |
| **Automation Potential** | [High/Medium/Low] |

---

## Workflow Observations

### Process: [Name]

**Current Steps:**
1. [Step] — [Who, how long, what tool]
2. [Step] — [Who, how long, what tool]

**Handoffs & Dependencies:**
- [Dependency 1]
- [Dependency 2]

**Workarounds Observed:**
- [Unofficial process]

---

## Opportunities Identified

### Explicit (They Suggested)
1. **[Title]** — [Description, approach, impact, complexity]

### Implicit (Inferred)
1. **[Title]** — [Based on, approach, impact, complexity]

---

## Key Quotes

| Topic | Quote | Significance |
|-------|-------|-------------|
| | "" | |
| | "" | |

---

## Quantified Data Summary

| Metric | Value | Source |
|--------|-------|--------|
| | | |

---

## Credibility Assessment

| Claim | Credibility | Notes |
|-------|-------------|-------|
| | [High/Med/Low] | |

---

## Follow-Up Items

- [ ] [Item]
- [ ] [Item]

---

## Pattern Indicators

- [Potential pattern] — [Evidence]
- [Potential pattern] — [Evidence]

---
Built with the AI Opportunity Finder by Morningside AI
