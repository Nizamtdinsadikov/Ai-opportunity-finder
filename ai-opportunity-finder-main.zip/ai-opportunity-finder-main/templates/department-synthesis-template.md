# Department Synthesis: [Department Name]
**Company:** [Company Name]
**Date:** [Date]
**Interviews Analyzed:** [Number]
**Interviewees:** [Names and roles]

---

## Main Insight

[ONE sentence: "[Department] spends [X hours/year] on [activity] that [impact]."]

---

## Core Problem

**What's fundamentally broken:**
[2-3 sentences]

**Validated by:**
| Source | Evidence |
|--------|----------|
| [Name, Role] | "[Quote]" |
| [Name, Role] | "[Quote]" |

**Confidence Level:** [High/Medium/Low]

---

## Why It's Happening

**Root Cause 1:** [Description]
**Root Cause 2:** [Description]
**Root Cause 3:** [Description]

---

## Quantified Impact

### Time Burden

| Process/Activity | Source | Hours/Week | Hours/Year | People |
|-----------------|--------|------------|------------|--------|
| | | | | |
| **Total** | | | | |

### Cost Estimate

| Category | Annual Hours | Cost at $50/hr | Cost at $75/hr |
|----------|-------------|----------------|----------------|
| | | | |
| **Total** | | | |

### Quality & Risk Impact
- [Issue 1]
- [Issue 2]

---

## Opportunities

### Quick Wins (2-8 weeks)

**1. [Name]**
| Dimension | Detail |
|-----------|--------|
| **Description** | |
| **Impact** | |
| **Complexity** | Low |
| **Dependencies** | |
| **Validated by** | |

### Strategic Initiatives (2-6 months)

**2. [Name]**
| Dimension | Detail |
|-----------|--------|
| **Description** | |
| **Impact** | |
| **Complexity** | [Medium/High] |
| **Dependencies** | |
| **Validated by** | |

---

## Cross-Interview Patterns

| Pattern | Sources | Confidence | Evidence |
|---------|---------|------------|----------|
| | | | |

---

## Implementation Considerations

**Prerequisites:** [List]
**Risks:** [List with mitigations]
**Success Factors:** [List]

---

## Department Summary Card

| Metric | Value |
|--------|-------|
| Total addressable hours/year | |
| Estimated annual cost | |
| Quick win opportunities | |
| Strategic opportunities | |
| Confidence level | |
| Top priority | |

---
Built with the AI Opportunity Finder by Morningside AI
