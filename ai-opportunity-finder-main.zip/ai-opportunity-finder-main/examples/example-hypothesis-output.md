# AI Opportunity Hypotheses: Major Sports Franchise
**Generated:** 2025-11-15
**Industry:** Professional Sports
**Company Size:** ~100 employees (basketball operations)
**Focus Areas:** Performance, Coaching, Scouting, Analytics, Operations

## Executive Summary

This organization has invested heavily in data infrastructure but struggles to translate raw data into actionable insights. With 10+ departments sharing overlapping data needs and a small analytics team, the biggest opportunities likely center on automated reporting, scheduling coordination, and insight synthesis.

---

## Hypothesis 1: Death by Tables — Data Without Insights

**Department:** Performance, Coaching, Analytics
**Pattern Match:** Data Without Insights

**We believe that** coaching and performance staff spend 15-20+ hours per opponent preparing game reports and analyzing data
**which could be** augmented using AI-powered report synthesis and natural language summaries,
**resulting in** 500-1,000 hours/year saved across departments and faster, better-quality game preparation.

**Why we think this:**
- Sports organizations typically invest in data platforms (tracking systems, statistical databases) but lack the analytics capacity to turn raw data into narrative insights
- When data teams are small (4-6 people) serving 10+ departments, they become bottlenecks

**To validate, interview:**
- VP of Performance — Ask: "How do you access game and health data? What's your turnaround time for insights?"
- Assistant Coach — Ask: "Walk me through preparing for an opponent. How much time is data gathering vs. analysis?"
- Head of Analytics — Ask: "What percentage of your time is reactive vs. proactive? Who are you serving?"

**Confidence:** High
**Potential Impact:** 500-1,000 hours/year
**Quick Win Potential:** Yes — automated report generation from existing data sources

---

## Hypothesis 2: Manual Scheduling Cascade

**Department:** Performance, Coaching, Travel, Operations
**Pattern Match:** Manual Scheduling Cascade

**We believe that** schedule changes from the head coach cascade into 5+ hours of manual updates across departments
**which could be** automated using a centralized scheduling system with dependency-aware notifications,
**resulting in** 1,000-1,500 hours/year saved and significant reduction in scheduling errors.

**Why we think this:**
- Multi-department organizations with a single "master schedule" driver (e.g., head coach, CEO) typically create manual cascades
- In sports, practice schedules drive medical appointments, travel logistics, equipment prep, and video schedules

**To validate, interview:**
- Strength Coach — Ask: "What happens to your schedule when practice time changes? How do you find out?"
- Travel Coordinator — Ask: "How do you learn about schedule changes? How do you update bookings?"
- Head of Scouting — Ask: "How do you coordinate your schedule with the team calendar?"

**Confidence:** High
**Potential Impact:** 1,000-1,500 hours/year
**Quick Win Potential:** No — requires cross-department coordination (strategic initiative)

---

## Hypothesis 3: Report Assembly Line

**Department:** Scouting, Performance, Analytics, Front Office
**Pattern Match:** Report Assembly Line

**We believe that** staff spend significant time reformatting the same information for different audiences
**which could be** automated using AI-powered multi-format report generation,
**resulting in** 800-1,200 hours/year saved on report creation and reformatting.

**Why we think this:**
- Organizations with multiple reporting lines (board, leadership, department heads, frontline) often create the same content 3-4 times in different formats
- Scouting reports in particular tend to be high-volume, semi-structured content

**To validate, interview:**
- VP of Scouting — Ask: "How many scouting reports does your team produce per year? How many formats?"
- VP of Basketball Ops — Ask: "What reports do you prepare for the GM? How much time does that take?"
- Data Scientist — Ask: "How much of your time is report generation vs. actual analysis?"

**Confidence:** Medium
**Potential Impact:** 800-1,200 hours/year
**Quick Win Potential:** Yes — start with one report type and expand

---

## Recommended Interview Order

### Phase 1: Executives (Days 1-2)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|
| General Manager | Strategic vision, what a "win" looks like for AI | "What keeps you up at night? Where is the org falling behind?" |
| VP of Performance | Oversees data-heavy department, likely feels the pain | "How does data flow to your team? What's missing?" |

### Phase 2: Frontline Workers (Days 3-7)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|
| Assistant Coaches (2-3) | Daily users of data, feel the scheduling cascade | "Walk me through game prep. What takes the most time?" |
| Strength & Conditioning Coach | Key scheduling victim, medical data user | "How do you get your schedule? What happens when it changes?" |
| Scouting Staff (2) | High-volume report producers | "How many reports per week? How long does each take?" |
| Travel Coordinator | Downstream schedule victim | "How do you learn about changes? Manual or automated?" |
| Head Athletic Trainer | Medical data owner, scheduling stakeholder | "How do you communicate player availability across departments?" |
| IT Manager | Technical landscape, what's possible | "What systems does the org use? What integrates with what?" |

### Phase 3: Back to Executives (Days 8-10)
| Purpose | What to Validate |
|---------|-----------------|
| Confirm scheduling cascade is as bad as reported | "We heard X hours/year on scheduling. Does that match your sense?" |
| Test appetite for centralized systems | "Would a unified scheduling tool be welcomed or resisted?" |
| Validate prototype direction | "If we showed you a dashboard that did X, would that be useful?" |

---

## Patterns to Watch For

| Pattern | Description | Likelihood |
|---------|-------------|------------|
| Data Without Insights | Raw data available but no synthesis layer | 90% — almost universal in sports |
| Manual Scheduling Cascade | One schedule change triggers hours of manual updates | 85% — high in multi-department orgs |
| Text Message as System of Record | Critical info flows through texts, not systems | 80% — common in fast-moving environments |
| Institutional Knowledge in Heads | Key processes depend on specific people's memory | 75% — especially in tenured staff |

---

## Next Steps

1. `/interview-builder` — Create tailored interview guides for each role above
2. `/workflow-audit` — Deep-dive into the scheduling process (Hypothesis 2)
3. After interviews: `/insight-analyzer` — Process findings

---
Built with the AI Opportunity Finder by Morningside AI
