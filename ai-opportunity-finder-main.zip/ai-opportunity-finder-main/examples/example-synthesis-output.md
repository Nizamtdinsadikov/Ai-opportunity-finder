# Department Synthesis: Performance & Sports Science
**Company:** Major Sports Franchise
**Date:** 2025-11-22
**Interviews Analyzed:** 4
**Interviewees:** VP of Performance, Head Strength Coach, Head Athletic Trainer, Biomechanics Data Scientist

---

## Main Insight

The Performance department spends **1,200+ hours/year** on manual data gathering, report assembly, and cross-system coordination that prevents them from doing the proactive injury prevention and performance optimization work they were hired to do.

---

## Core Problem

**What's fundamentally broken:**
The department has invested in world-class data systems (wearables, medical records, tracking technology) but lacks the synthesis layer to turn that data into actionable intelligence. Staff spend their time pulling and reformatting data instead of analyzing it. The central analytics team — the only group that could help — doesn't have capacity to serve them during the 8-month competitive season.

**Validated by:**
| Source | Evidence |
|--------|----------|
| VP of Performance | "Death by tables... we have too much data and we don't have the resource to maximize the value" |
| Head Strength Coach | "I spend 30-45 minutes every day just building the schedule from screenshots and texts" |
| Head Athletic Trainer | "I'm tracking everything on paper and then re-entering it into the system. It's double work." |
| Data Scientist | "70% of my time is data cleaning and formatting. Maybe 30% is actual analysis." |

**Confidence Level:** High (4/4 interviewees independently described the same core problem)

---

## Why It's Happening

**Root Cause 1:** Data systems don't integrate
- 4+ platforms with no unified API or shared data layer
- Each system was purchased independently; none were designed to work together

**Root Cause 2:** Analytics team is undersized for demand
- 6-person team serving 10+ departments
- During season, consumed by game-day and front-office requests
- "Once the season starts, they don't have capacity to service us"

**Root Cause 3:** No automation of routine outputs
- Monthly reports, daily schedules, and status updates are all produced manually
- Same data reformatted 3-4 times for different audiences
- No one has built the "plumbing" to automate these flows

---

## Quantified Impact

### Time Burden

| Process/Activity | Source | Hours/Week | Hours/Year | People |
|-----------------|--------|------------|------------|--------|
| Data cross-referencing | VP Performance | 8-10 | 400-500 | 6 |
| Monthly player reports | VP Performance | 2 (avg) | 100 | 1 |
| Daily schedule building | Strength Coach | 3-4 | 150-200 | 1 |
| Medical data double-entry | Athletic Trainer | 5 | 250 | 1 |
| Data cleaning/formatting | Data Scientist | 7 | 350 | 1 |
| **Total** | | **25-28** | **1,250-1,400** | |

### Cost Estimate

| Category | Annual Hours | Cost at $50/hr | Cost at $75/hr |
|----------|-------------|----------------|----------------|
| Data gathering & cross-referencing | 500 | $25,000 | $37,500 |
| Report assembly | 250 | $12,500 | $18,750 |
| Schedule coordination | 200 | $10,000 | $15,000 |
| Data double-entry & cleaning | 350 | $17,500 | $26,250 |
| **Total** | **1,300** | **$65,000** | **$97,500** |

### Quality & Risk Impact

- Injury risk signals may be missed because data sits in separate systems
- Athletic trainer's paper-based tracking creates a single point of failure
- Coaches receive "death by tables" reports they don't fully use — wasted effort

---

## Opportunities

### Quick Wins (2-8 weeks)

**1. Automated Monthly Player Reports**
| Dimension | Detail |
|-----------|--------|
| **Description** | AI generates draft monthly player reports from existing medical, wearable, and performance data. VP reviews and edits instead of building from scratch. |
| **Impact** | 100 hours/year saved + faster turnaround + more consistent quality |
| **Complexity** | Low — data is structured, report format is consistent |
| **Dependencies** | Read access to 3 data systems |
| **Validated by** | VP Performance ("If the report could write itself from the data, I'd just review and tweak"), Data Scientist (confirmed data is accessible) |
| **Why it's a quick win** | Structured input, consistent output, single user champion, immediate visibility |

**2. Data Scientist Workflow Automation**
| Dimension | Detail |
|-----------|--------|
| **Description** | Automate routine data cleaning and formatting tasks that consume 70% of the data scientist's time. |
| **Impact** | 250 hours/year freed for actual analysis |
| **Complexity** | Low — repetitive, rule-based tasks |
| **Dependencies** | Data scientist to define cleaning rules |
| **Validated by** | Data Scientist ("70% of my time is data cleaning and formatting") |

### Strategic Initiatives (2-6 months)

**3. Unified Player Health Dashboard**
| Dimension | Detail |
|-----------|--------|
| **Description** | Single dashboard aggregating medical records, wearable data, and performance metrics per player. Replaces the VP's personal tracking spreadsheet and 4-system login routine. |
| **Impact** | 400-500 hours/year saved + better decision quality + proactive insights |
| **Complexity** | Medium — requires data integration across 4 systems |
| **Dependencies** | IT support for API access, data governance review |
| **Validated by** | VP Performance ("If AI can pull from all our systems and give me one view per player, that would change everything"), Athletic Trainer (confirmed data overlap), Data Scientist (confirmed technical feasibility) |

**4. Proactive Injury Risk Alerting System**
| Dimension | Detail |
|-----------|--------|
| **Description** | ML model analyzing patterns across wearable, medical, and performance data to flag elevated injury risk. |
| **Impact** | Hard to quantify — preventing 1 major injury could save millions in salary and competitive impact |
| **Complexity** | High — requires data science, model validation, medical review |
| **Dependencies** | Unified data layer (Opportunity 3), medical staff buy-in, validation period |
| **Validated by** | VP Performance ("If AI can be doing proactive thinking for us, that would be a huge step forward") |

---

## Cross-Interview Patterns Detected

| Pattern | # of Sources | Confidence | Evidence |
|---------|-------------|------------|----------|
| Data Without Insights | 4/4 | High | All interviewees describe data overload without synthesis |
| Report Assembly Line | 3/4 | High | VP, Data Scientist, and Athletic Trainer all describe reformatting work |
| Manual Scheduling Cascade | 2/4 | Medium | Strength Coach and Athletic Trainer describe schedule-driven manual work |
| Text Message as System of Record | 2/4 | Medium | Strength Coach texts schedules to players; Athletic Trainer texts updates |

---

## Implementation Considerations

**Prerequisites:**
- IT to provide read-only API access to medical, wearable, and performance systems
- Data governance review for player health data (sensitivity)
- VP Performance to champion internally

**Risks:**
- Data privacy — player health data is sensitive → Mitigation: Role-based access controls, no raw data exposure
- Staff resistance — "the system works fine" → Mitigation: Start with automated reports (low threat), demonstrate time savings

**Success Factors:**
- VP Performance is enthusiastic and will champion adoption
- Data Scientist confirmed technical feasibility
- Quick Win (automated reports) can demonstrate value in 2-4 weeks before bigger asks

**Change Management Notes:**
- All 4 interviewees expressed appetite for change — low resistance expected
- Key concern: "Don't give me another system to learn" — solution must integrate into existing workflow, not add a new tool

---

## Department Summary Card

| Metric | Value |
|--------|-------|
| Total addressable hours/year | 1,250-1,400 |
| Estimated annual cost | $65,000-$97,500 |
| Quick win opportunities | 2 |
| Strategic opportunities | 2 |
| Confidence level | High |
| Top priority | Automated Monthly Player Reports |

---
Built with the AI Opportunity Finder by Morningside AI
