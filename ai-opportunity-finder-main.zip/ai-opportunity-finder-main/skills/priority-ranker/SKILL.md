---
name: priority-ranker
description: Ruthlessly prioritize AI opportunities across departments using Impact x Feasibility scoring. Applies the Executive Test, eliminates low-value items, combines related opportunities into workstreams, and produces a ranked priority matrix. Use after running /department-synthesizer for 2+ departments.
argument-hint: "[company-name]"
---

# Priority Ranker

Takes all your department syntheses and ruthlessly prioritizes opportunities. This is where most DIY discovery efforts fall apart — finding problems is easy, but knowing which ones to solve first is hard. This skill applies the same prioritization framework used by professional AI consultants.

## Why Ruthless Prioritization Matters

You will find more opportunities than you can possibly pursue. The temptation is to try to fix everything — don't. Organizations that chase 20 initiatives simultaneously accomplish nothing. Organizations that nail 3 priorities create momentum.

**The goal: from many opportunities to 5-7 that actually matter.**

## What I Need From You

1. **All Department Synthesis documents** (from `/department-synthesizer`)
2. **Organization context:**
   - Company name and size
   - Strategic priorities from leadership (what does the CEO/owner care about most?)
   - Known constraints (budget range, timeline expectations, technical limitations)
   - Internal capacity (do you have technical people? AI experience?)
3. **Any additional findings** not captured in department syntheses

## What You'll Get

An **Organization-Wide Priority Matrix** with:
- Ranked opportunities (with clear rationale)
- MECE workstreams (no overlaps, no gaps)
- Quick Wins vs Strategic Initiatives
- Implementation roadmap (what to do first, second, third)
- Executive-ready summary

## Prioritization Framework

### Step 1: Eliminate Low-Value Items

Any opportunity with:
- < $50K annual value OR < 500 hours/year saved → **Cut it**
- Vague impact that can't be quantified → **Cut it**
- No internal champion to push it forward → **Deprioritize**

This typically eliminates 30-50% of identified opportunities.

### Step 2: Combine Related Items

Multiple scheduling problems = 1 Scheduling workstream
Multiple reporting problems = 1 Reporting Automation workstream
Multiple data access problems = 1 Data & Insights workstream

**MECE principle:** Mutually Exclusive, Collectively Exhaustive. No overlaps, no gaps.

### Step 3: The Executive Test

For each remaining opportunity, ask:
> "Would the CEO/owner immediately understand why this matters?"

If the answer requires explanation → deprioritize. Executives don't have time for nuance. Your opportunities need to be obviously valuable.

### Step 4: Score on Impact × Feasibility

**Impact scoring:**
| Rating | Criteria |
|--------|----------|
| **High** | >1,000 hours/year saved OR >$75K annual value OR affects 5+ people |
| **Medium** | 500-1,000 hours/year OR $25-75K OR affects 2-4 people |
| **Low** | <500 hours/year OR <$25K OR affects 1 person |

**Feasibility scoring:**
| Rating | Criteria |
|--------|----------|
| **High** | 2-8 weeks to build, existing tools/data, low change management |
| **Medium** | 2-3 months, needs some integrations or data work |
| **Low** | 3+ months, requires significant infrastructure or organizational change |

### Step 5: Rank and Sequence

| Priority | Combination | Action |
|----------|-------------|--------|
| **1st** | High Impact + High Feasibility | **Do this now** |
| **2nd** | High Impact + Medium Feasibility | **Plan for next quarter** |
| **3rd** | Medium Impact + High Feasibility | **Quick win — build credibility** |
| **4th** | Medium Impact + Medium Feasibility | **Evaluate after top 3** |
| **Skip** | Anything with Low Impact | **Not worth the investment** |
| **Backlog** | High Impact + Low Feasibility | **Strategic — revisit in 6 months** |

## Output Format

```markdown
# AI Opportunity Priority Matrix: [Company Name]
**Date:** [Date]
**Departments Analyzed:** [List]
**Total Interviews:** [Number]
**Total Opportunities Identified:** [Number]
**Prioritized Opportunities:** [Number]

---

## Executive Summary

[3-5 sentences: What we analyzed, what we found, what we recommend]

**Key Numbers:**
- Total addressable hours/year: [X]
- Estimated annual cost of inefficiency: $[Y]
- Opportunities identified: [Total]
- Priority opportunities: [Top 5-7]
- Potential ROI of top 3 priorities: $[Z]

---

## Eliminated Opportunities

The following were identified but **do not warrant investment** at this time:

| Opportunity | Why Eliminated |
|-------------|----------------|
| [Name] | [Below threshold / no champion / vague impact] |
| [Name] | [Reason] |

---

## Consolidated Workstreams

### Workstream 1: [Name] (e.g., "Scheduling & Coordination")
**Departments Affected:** [List]
**Total Hours/Year:** [Aggregated from department syntheses]
**Annual Cost:** $[Amount]

**Component Opportunities:**
- [Original opportunity 1 from Dept A]
- [Original opportunity 2 from Dept B]
- [Original opportunity 3 from Dept C]

**Why These Are One Workstream:** [Explanation of how they connect]

### Workstream 2: [Name]
...

---

## Priority Matrix

| Rank | Opportunity | Workstream | Impact | Feasibility | Hours Saved | Est. Value | Executive Test |
|------|-------------|-----------|--------|-------------|-------------|------------|----------------|
| 1 | [Name] | [WS] | High | High | [X] | $[Y] | Pass |
| 2 | [Name] | [WS] | High | High | [X] | $[Y] | Pass |
| 3 | [Name] | [WS] | High | Medium | [X] | $[Y] | Pass |
| 4 | [Name] | [WS] | Medium | High | [X] | $[Y] | Pass |
| 5 | [Name] | [WS] | High | Medium | [X] | $[Y] | Pass |
| 6 | [Name] | [WS] | Medium | Medium | [X] | $[Y] | Pass |
| 7 | [Name] | [WS] | Medium | Medium | [X] | $[Y] | Pass |

---

## Quick Wins (Start in Weeks 1-4)

These are high-feasibility opportunities that deliver visible results fast. They build credibility for larger initiatives.

### 1. [Opportunity Name]
- **What:** [One sentence]
- **Who benefits:** [Department/roles]
- **Expected result:** [Specific, measurable outcome]
- **Timeline:** [X weeks]
- **Why start here:** [Visible, achievable, builds momentum]

### 2. [Opportunity Name]
...

---

## Strategic Initiatives (Months 2-6)

These require more investment but deliver transformational value.

### 1. [Opportunity Name]
- **What:** [One sentence]
- **Who benefits:** [Department/roles]
- **Expected result:** [Specific, measurable outcome]
- **Timeline:** [X months]
- **Investment required:** [Rough scope — internal capacity, external help, tools]
- **Prerequisites:** [What needs to happen first]

---

## Cross-Cutting Themes

Patterns that appear across multiple departments:

### Theme 1: [Name]
- **Departments affected:** [List]
- **Pattern:** [Description of the recurring problem]
- **Why it matters:** [Organization-wide impact]
- **Best addressed by:** [Which priority opportunity]

### Theme 2: [Name]
...

---

## Implementation Roadmap

### Immediate (Weeks 1-4)
| Action | Owner | Dependencies |
|--------|-------|-------------|
| [Quick Win 1] | [Suggested role] | [None / minimal] |
| [Quick Win 2] | [Suggested role] | [None / minimal] |

### Near-Term (Months 2-3)
| Project | Owner | Investment | Dependencies |
|---------|-------|------------|-------------|
| [Initiative 1] | [Suggested role] | [Scope] | [Prerequisites] |

### Strategic (Months 4-6)
| Initiative | Sponsor Needed | Investment | Dependencies |
|------------|---------------|------------|-------------|
| [Initiative 1] | [Executive level] | [Scope] | [Earlier phases] |

---

## What's Not Covered (The Ceiling)

This prioritization focuses on individual department opportunities. There are likely
**cross-department systemic opportunities** that only become visible when you look
across the entire organization simultaneously. Common examples:

- Organization-wide data fragmentation patterns
- Scheduling cascades that affect 5+ departments
- Analytics bottlenecks that constrain multiple teams
- Communication infrastructure gaps

Identifying these requires deeper, embedded analysis — typically through a
professional discovery engagement.

---

## Next Steps

1. Run `/executive-briefing` to create a presentation from these priorities
2. Start with Quick Win #1 — build credibility before tackling strategic initiatives
3. Assign internal owners for each priority

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help running a full Discovery Sprint? → https://morningside.ai
```

## Common Prioritization Mistakes

- **Chasing feasibility over impact.** Easy-to-build doesn't mean worth building. A 2-week project that saves 50 hours/year isn't worth it.
- **Equal weighting everything.** Not all opportunities are created equal. Be comfortable saying "this one matters 10x more than that one."
- **Ignoring the champion factor.** A great opportunity with no internal champion will die on the vine. Who will push this forward when you're not in the room?
- **Over-indexing on technology.** The question isn't "can we build this?" — it's "will anyone use it, and will it actually matter?"

## Tips for Best Results

- **Include leadership priorities.** The best-quantified opportunity in the world won't get funded if it doesn't align with what the CEO cares about. Always filter through strategic priorities.
- **Be honest about constraints.** If you have zero technical capacity internally, even "High Feasibility" items will need external help. Factor that in.
- **Don't just rank — sequence.** Order matters. Quick wins first build credibility for the bigger asks.
