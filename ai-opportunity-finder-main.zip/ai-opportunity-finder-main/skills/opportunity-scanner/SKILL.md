---
name: opportunity-scanner
description: Generate AI opportunity hypotheses for your company. Identifies where AI and automation can save time, reduce errors, and create competitive advantages based on your industry, company size, and known pain points. Use when starting an AI discovery initiative or when you need a structured starting point for finding AI opportunities.
argument-hint: "[company-name] [industry]"
---

# AI Opportunity Scanner

Generates 3-5 testable AI opportunity hypotheses for your organization based on industry patterns, company size, and known challenges. This is Step 1 of the Discovery Sprint methodology — giving you a structured starting point instead of "where do we even begin?"

## How It Works

When you run this skill, I'll ask you a few questions about your company, then generate a structured hypothesis document you can use to guide interviews, audits, and deeper investigation.

## What I Need From You

Provide the following (I'll ask for anything missing):

1. **Company name**
2. **Industry** (e.g., Healthcare, Manufacturing, Professional Services, Retail, Finance, Technology, etc.)
3. **Company size** (approximate employee count)
4. **2-5 known challenges or pain points** (what keeps leadership up at night?)
5. **Key departments to focus on** (optional — if you already know where the biggest problems are)

## What You'll Get

A **Hypothesis Document** containing:

### For Each Hypothesis (3-5 total):

```
HYPOTHESIS: We believe that [DEPARTMENT/FUNCTION] spends significant time on
[ACTIVITY] which could be [AUTOMATED/AUGMENTED] using [AI APPROACH],
resulting in [ESTIMATED IMPACT].

VALIDATION METHOD:
- Who to interview: [Roles/people]
- Questions to ask: [Specific questions]
- Data to collect: [Metrics to validate]

CONFIDENCE: [High/Medium/Low] based on industry pattern strength
POTENTIAL IMPACT: [Hours/year saved or $ value range]
```

### Plus:

- **Interview Priority List** — Who to talk to first, organized by the U-shaped method (executives first, then frontline, then back to executives)
- **Pattern Alerts** — Common patterns your industry typically exhibits (so you know what to watch for)
- **Quick Win Candidates** — 1-2 hypotheses most likely to yield fast, visible results

## Industry Pattern Library

I draw on validated patterns seen across multiple organizations:

| Pattern | Description | Industries Where Common |
|---------|-------------|------------------------|
| **Data Without Insights** | Lots of data in tables/systems but no synthesis into actionable intelligence | All industries with data teams |
| **Manual Scheduling Cascade** | Schedule changes require manual updates across multiple people/systems | Operations-heavy, multi-department |
| **Report Assembly Line** | Same information reformatted for different audiences manually | Any org with reporting requirements |
| **Institutional Knowledge in Heads** | Critical processes depend on specific people's memory | Mature orgs, specialized domains |
| **Communication Silos** | Information flows through personal relationships, not systems | Multi-department, 50+ employees |
| **Analytics Capacity Crunch** | Analytics team is bottleneck; can't serve all departments | Any org with central analytics |
| **Text/Email as System of Record** | Critical info lives in messages, not structured systems | Orgs that outgrew their tools |

## How I Generate Hypotheses

1. **Match your industry** to known automation patterns
2. **Adjust for company size** (smaller = more quick wins; larger = more strategic initiatives)
3. **Cross-reference your stated challenges** with pattern library
4. **Estimate impact ranges** using industry benchmarks
5. **Prioritize by likelihood** — hypotheses backed by strong patterns rank higher

## Output Format

I'll create a markdown file you can save and reference throughout your discovery process:

```markdown
# AI Opportunity Hypotheses: [Company Name]
Generated: [Date]
Industry: [Industry] | Size: [Employees] | Focus: [Departments]

## Executive Summary
[2-3 sentences on the most promising opportunity areas]

---

## Hypothesis 1: [Title]
**Department:** [Department]
**Pattern Match:** [Which known pattern this maps to]

**We believe that** [department/function] spends [estimated time] on [activity]
**which could be** [automated/augmented] using [AI approach],
**resulting in** [estimated impact: hours saved, cost reduction, quality improvement].

**Why we think this:**
- [Industry benchmark or pattern evidence]
- [Connection to stated challenge]

**To validate, interview:**
- [Role 1] — Ask: "[Specific question]"
- [Role 2] — Ask: "[Specific question]"

**Confidence:** [High/Medium/Low]
**Potential Impact:** [Range]
**Quick Win Potential:** [Yes/No — and why]

---

[Repeat for each hypothesis]

---

## Recommended Interview Order

### Phase 1: Executives (Days 1-2)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|

### Phase 2: Frontline Workers (Days 3-7)
| Person/Role | Why Interview Them | Key Questions |
|-------------|-------------------|---------------|

### Phase 3: Back to Executives (Days 8-10)
| Purpose | What to Validate |
|---------|-----------------|

---

## Patterns to Watch For
Based on your industry and size, keep an eye out for:
- [Pattern 1 with description]
- [Pattern 2 with description]
- [Pattern 3 with description]

---

## Next Steps
1. Run `/interview-builder` to create tailored interview guides for each target
2. Run `/workflow-audit` to deep-dive into the highest-confidence hypothesis
3. After interviews, run `/insight-analyzer` to process findings

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help? → https://morningside.ai
```

## Tips for Best Results

- **Be specific about challenges.** "Sales is slow" is less useful than "Reps spend 3+ hours/day on CRM data entry and prospecting research."
- **Name departments if you can.** The more specific you are, the more targeted the hypotheses.
- **It's OK to be wrong.** These are hypotheses, not conclusions. The point is to have a starting direction. You'll validate (or invalidate) through interviews.

## What Comes Next

After generating hypotheses:
1. **`/workflow-audit`** — Deep-dive into a specific process you suspect is wasteful
2. **`/interview-builder`** — Create interview guides for the people identified in your hypothesis document
3. **`/insight-analyzer`** — Process interview transcripts into structured findings
