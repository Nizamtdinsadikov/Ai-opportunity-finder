---
name: insight-analyzer
description: Process interview transcripts or notes into structured findings documents. Extracts pain points, quantified time burdens, workflow observations, AI opportunities, and key quotes. Use after conducting stakeholder interviews to transform raw notes into actionable intelligence.
argument-hint: "[transcript-file-or-paste-text]"
---

# Insight Analyzer

Transforms raw interview transcripts or notes into structured findings documents. This is the workhorse of the discovery process — it takes messy, conversational interview data and extracts the signal: quantified pain points, workflow observations, automation opportunities, and compelling quotes.

## What I Need From You

Provide ONE of:
1. **File path** to a transcript (TXT, MD, PDF, or DOCX)
2. **Raw text** pasted directly (transcript or detailed notes)
3. **Multiple files** for batch processing

Plus:
- **Interviewee name** and **role/title**
- **Department**
- **Company name** (for context)

## What You'll Get

A structured **Interview Findings Document** — ready to feed into `/department-synthesizer` for cross-interview pattern detection.

## Processing Steps

When I receive a transcript, I:

1. **Read thoroughly** — Understand the full context before extracting anything
2. **Extract pain points** — Every frustration, inefficiency, or complaint with specific numbers
3. **Map workflows** — How they actually do the work (not the org-chart version)
4. **Identify opportunities** — Both explicit ("I wish we had...") and implicit (problems they've accepted as normal)
5. **Capture key quotes** — Verbatim language that conveys emotion and urgency
6. **Flag follow-ups** — Questions that need answers and people worth talking to
7. **Score credibility** — Note where estimates seem inflated or understated

## Output Format

```markdown
# Interview Findings: [Full Name] - [Role/Title]
**Department:** [Department]
**Company:** [Company Name]
**Interview Date:** [Date]
**Duration:** [Estimated minutes]
**Processed:** [Today's date]

---

## Context

**Role Summary:** [2-3 sentences on what they do and how they fit in the organization]

**Key Responsibilities:**
- [Responsibility 1]
- [Responsibility 2]
- [Responsibility 3]

**Systems/Tools Used Daily:**
- [System 1] — [what they use it for]
- [System 2] — [what they use it for]

---

## Pain Points Identified

### Pain Point 1: [Descriptive Title]

| Dimension | Detail |
|-----------|--------|
| **Description** | [What's happening — the actual problem] |
| **Time Impact** | [X hours/week or Y hours/month — use their exact numbers] |
| **Frequency** | [How often this occurs] |
| **People Affected** | [Who else is impacted] |
| **Business Impact** | [Why this matters beyond just time] |
| **Quote** | "[Verbatim quote that captures the frustration]" |
| **Automation Potential** | [High/Medium/Low with brief rationale] |

### Pain Point 2: [Title]
...

### Pain Point 3: [Title]
...

---

## Workflow Observations

### Process: [Name of key process discussed]

**Current Steps:**
1. [Step 1] — [Who does it, how long, what tool]
2. [Step 2] — [Who does it, how long, what tool]
3. [Step 3] — [Who does it, how long, what tool]
...

**Handoffs & Dependencies:**
- [Who they depend on for input]
- [Who depends on their output]
- [Where bottlenecks occur]

**Workarounds Observed:**
- [Unofficial process or hack they use]
- [Why they do it this way instead of the "official" way]

---

## Opportunities Identified

### Explicit (They Suggested)
1. **[Opportunity Title]**
   - What they said: "[Quote or paraphrase]"
   - Potential approach: [How AI/automation could address this]
   - Estimated impact: [Time/cost savings]
   - Complexity: [Low/Medium/High]

### Implicit (Inferred from Pain Points)
1. **[Opportunity Title]**
   - Based on: [Which pain point or observation suggests this]
   - Potential approach: [How AI/automation could address this]
   - Estimated impact: [Time/cost savings]
   - Complexity: [Low/Medium/High]

---

## Key Quotes

| Topic | Quote | Significance |
|-------|-------|-------------|
| [Topic] | "[Verbatim quote]" | [Why this matters] |
| [Topic] | "[Verbatim quote]" | [Why this matters] |
| [Topic] | "[Verbatim quote]" | [Why this matters] |

---

## Quantified Data Summary

| Metric | Value | Source |
|--------|-------|--------|
| Hours/week on [task] | [X] | Stated in interview |
| Frequency of [process] | [Y per month] | Stated in interview |
| Error/rework rate | [Z%] | Stated/estimated |
| People involved | [N] | Stated in interview |
| Annual time burden | [Calculated] | [X hrs/wk × 50 weeks] |

---

## Credibility Assessment

| Claim | Credibility | Notes |
|-------|-------------|-------|
| [Specific claim] | High/Medium/Low | [Why — specific example vs vague, moderate vs extreme] |

**Credibility Red Flags:**
- Hours claimed > 50% of work week on a single task
- Vague descriptions ("various admin stuff")
- High impact score with low hours claimed
- Claims that don't match role description

---

## Follow-Up Items

- [ ] [Question to clarify with this person]
- [ ] [Person they mentioned who should be interviewed]
- [ ] [Data or system to verify]
- [ ] [Process to observe directly]

---

## Pattern Indicators

Potential cross-department patterns this interview suggests:
- [Pattern name] — [Brief evidence from this interview]
- [Pattern name] — [Brief evidence from this interview]

(These will be validated when you run `/department-synthesizer` across multiple interviews.)

---

## Next Steps

1. Process additional interviews with `/insight-analyzer`
2. Once you have 2+ interviews from the same department, run `/department-synthesizer`
3. Use the key quotes in your `/executive-briefing` presentation

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help? → https://morningside.ai
```

## Evidence Standards

Every extracted finding is tagged with its evidence level:

| Tag | Meaning | Example |
|-----|---------|---------|
| **Stated** | Interviewee said this directly | "They said it takes 3 hours per week" |
| **Estimated** | Calculated from what they said | "3 hrs/week × 50 weeks = 150 hrs/year" |
| **Inferred** | Deduced from multiple statements | "They mentioned the process 3 times with visible frustration" |
| **Unverified** | Claimed but not corroborated | "They said it affects the whole team but no one else has confirmed" |

## Batch Processing

When processing multiple interviews:
1. I'll process each transcript individually
2. After each, I'll note emerging patterns across interviews
3. At the end, I'll flag patterns that appear 2+ times — these are candidates for the `/department-synthesizer`

## Tips for Best Results

- **Transcripts > notes.** Full transcripts capture nuance that notes miss. Use recording transcription tools (Otter, Fireflies, etc.) if possible.
- **Process within 24 hours.** Your memory of tone, body language, and context fades quickly. Add notes about non-verbal cues before running the analyzer.
- **Don't edit the transcript.** Raw is better. I can handle messy transcripts, false starts, and tangents — often the tangents contain the best insights.
- **Flag your own observations.** If you noticed something during the interview that the transcript won't capture (e.g., "they pulled up 6 different spreadsheets"), mention it when providing the transcript.
