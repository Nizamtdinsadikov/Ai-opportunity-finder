---
name: department-synthesizer
description: Aggregate multiple interview findings into a department-level synthesis. Identifies cross-interview patterns, quantifies total impact, and categorizes opportunities as Quick Wins or Strategic Initiatives. Use after processing 2+ interviews from the same department with /insight-analyzer.
argument-hint: "[department-name]"
---

# Department Synthesizer

Takes multiple interview findings documents (from `/insight-analyzer`) for a single department and synthesizes them into one consolidated view. This is where individual data points become organizational patterns — where "one person complains about scheduling" becomes "scheduling costs this department 800 hours/year."

## Why This Matters

Individual interviews are interesting. Synthesis is where the money is.

When 3 people in the same department independently describe the same frustration, that's no longer an opinion — it's a validated organizational problem. This skill does that triangulation for you.

## What I Need From You

1. **Department name**
2. **2 or more Interview Findings documents** (output from `/insight-analyzer`)
   - Provide as file paths or paste the content directly
3. **Survey data** (optional — if you ran a pre-interview survey)
4. **Any additional context** about the department (headcount, budget, strategic importance)

## What You'll Get

A **Department Synthesis Document** — the definitive view of one department's AI opportunities.

## Processing Logic

When I receive the findings, I:

1. **Inventory all pain points** across all interviews
2. **Triangulate** — Flag any pain point mentioned by 2+ people as validated
3. **Aggregate quantification** — Sum hours across interviewees, calculate department-wide impact
4. **Identify root causes** — Connect surface-level complaints to underlying systemic issues
5. **Categorize opportunities** — Quick Wins (2-8 weeks, low complexity) vs Strategic (2-6 months, higher complexity)
6. **Score each opportunity** on Impact and Feasibility

## Output Format

```markdown
# Department Synthesis: [Department Name]
**Company:** [Company Name]
**Date:** [Date]
**Interviews Analyzed:** [Number]
**Interviewees:** [Names and roles]

---

## Main Insight

[ONE powerful sentence that captures the core finding for this department.]

Format: "[Department] spends [X hours/year] on [activity] that [impact statement]."

---

## Core Problem

**What's fundamentally broken:**
[2-3 sentence description of the systemic issue — not just symptoms, but the underlying problem]

**Validated by:**
| Source | Evidence |
|--------|----------|
| [Name, Role] | "[Quote or finding]" |
| [Name, Role] | "[Quote or finding]" |
| [Name, Role] | "[Quote or finding]" |

**Confidence Level:** [High (3+ sources) / Medium (2 sources) / Low (1 source + inference)]

---

## Why It's Happening

**Root Cause 1:** [Description]
- Evidence: [What points to this cause]

**Root Cause 2:** [Description]
- Evidence: [What points to this cause]

**Root Cause 3:** [Description]
- Evidence: [What points to this cause]

---

## Quantified Impact

### Time Burden

| Process/Activity | Source | Hours/Week | Hours/Year | People |
|-----------------|--------|------------|------------|--------|
| [Activity 1] | [Who reported it] | [X] | [X × 50] | [N] |
| [Activity 2] | [Who reported it] | [Y] | [Y × 50] | [N] |
| **Total** | | **[Sum]** | **[Sum]** | |

### Cost Estimate

| Category | Annual Hours | Cost at $50/hr | Cost at $75/hr |
|----------|-------------|----------------|----------------|
| Manual processes | [X] | $[Amount] | $[Amount] |
| Rework/errors | [Y] | $[Amount] | $[Amount] |
| Coordination overhead | [Z] | $[Amount] | $[Amount] |
| **Total** | **[Sum]** | **$[Sum]** | **$[Sum]** |

*Note: $50/hr is a conservative estimate for staff time. Adjust based on your actual loaded labor costs.*

### Quality & Risk Impact

- [Error rate or quality issue mentioned]
- [Risk identified (e.g., single point of failure, knowledge loss)]
- [Downstream impact on other departments]

---

## Opportunities

### Quick Wins (2-8 weeks, Low Complexity)

**1. [Opportunity Name]**
| Dimension | Detail |
|-----------|--------|
| **Description** | [What to build or change] |
| **Impact** | [Hours saved/year, $ value] |
| **Complexity** | Low |
| **Dependencies** | [What needs to be true] |
| **Validated by** | [Which interviewees support this] |
| **Why it's a quick win** | [Low technical complexity, data available, champion exists] |

**2. [Opportunity Name]**
...

### Strategic Initiatives (2-6 months, Medium-High Complexity)

**3. [Opportunity Name]**
| Dimension | Detail |
|-----------|--------|
| **Description** | [What to build or change] |
| **Impact** | [Hours saved/year, $ value] |
| **Complexity** | Medium / High |
| **Dependencies** | [What needs to be true — integrations, data, change management] |
| **Validated by** | [Which interviewees support this] |
| **Why it's strategic** | [Requires more investment but delivers transformational value] |

---

## Cross-Interview Patterns Detected

| Pattern | # of Sources | Confidence | Evidence |
|---------|-------------|------------|----------|
| [Pattern name] | [N] | [High/Med/Low] | [Brief evidence summary] |
| [Pattern name] | [N] | [High/Med/Low] | [Brief evidence summary] |

**Patterns appearing in 3+ interviews are high confidence and should be treated as organizational facts, not opinions.**

---

## Implementation Considerations

**Prerequisites:**
- [Data access needed]
- [System integrations required]
- [Stakeholder buy-in needed]

**Risks:**
- [Risk 1] — Mitigation: [How to address]
- [Risk 2] — Mitigation: [How to address]

**Success Factors:**
- [What needs to be true for this to work]
- [Who needs to champion this internally]

**Change Management Notes:**
- [How receptive were interviewees to change?]
- [Any resistance signals to watch for?]

---

## Department Summary Card

| Metric | Value |
|--------|-------|
| Total addressable hours/year | [X] |
| Estimated annual cost | $[Y] |
| Quick win opportunities | [N] |
| Strategic opportunities | [N] |
| Confidence level | [High/Medium/Low] |
| Top priority | [Opportunity name] |

---

## Next Steps

1. Run `/department-synthesizer` for other departments
2. Once all departments are synthesized, run `/priority-ranker` to compare across the organization
3. Use the Main Insight and Key Quotes in your `/executive-briefing`

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help? → https://morningside.ai
```

## Quality Checklist

Before considering a synthesis complete, verify:

- [ ] Main insight is ONE sentence with specific numbers
- [ ] Core problem validated by 2+ independent sources
- [ ] Impact quantified in both hours AND dollars
- [ ] Every opportunity categorized as Quick Win or Strategic
- [ ] Each opportunity has a complexity rating and dependencies listed
- [ ] Root causes identified (not just symptoms)
- [ ] Cross-interview patterns flagged with evidence counts

## Handling Conflicting Information

Sometimes interviewees disagree. When this happens:

- **Note the disagreement explicitly** — Don't average conflicting numbers
- **Weight by proximity** — The person closest to the work is usually more accurate
- **Flag for follow-up** — Disagreements often reveal the most interesting insights
- **Use ranges** — "Scheduling takes 5-15 hours/week (estimates vary by role)" is more honest than picking one number

## Tips for Best Results

- **Minimum 2 interviews per department.** One interview is an anecdote. Two is a data point. Three is a pattern.
- **Include different levels.** A manager and a frontline worker from the same department will give you very different perspectives — you need both.
- **Don't cherry-pick.** Include all findings, even ones that seem minor. Sometimes the "minor" pain point is actually the biggest time sink when you add it up.
