---
name: interview-builder
description: Create customized stakeholder interview guides for AI opportunity discovery. Generates 4-phase interview scripts with role-specific questions, hypothesis testing, and red flags to watch for. Use when preparing to interview employees about their workflows, pain points, and AI opportunities.
argument-hint: "[role] [department]"
---

# Interview Builder

Creates a customized, ready-to-use interview guide for stakeholder interviews. Based on the 4-phase interview methodology used by professional AI consultants — designed so anyone can run an effective discovery interview, even without consulting experience.

## Why This Matters

Most people don't know how to interview for AI opportunities. They ask vague questions ("Do you use AI?") and get vague answers. This skill creates targeted, role-specific interview scripts that uncover the real pain points — the ones people don't mention unless you ask the right way.

## What I Need From You

1. **Interviewee's role/title** (e.g., "VP of Operations", "Sales Manager", "Accounts Payable Clerk")
2. **Department** (e.g., "Finance", "Sales", "Operations")
3. **Hypotheses to test** (optional — from `/opportunity-scanner` output, or your own theories about where AI could help)
4. **Specific areas to probe** (optional — "we think reporting takes too long" or "scheduling seems manual")
5. **Interview duration** (default: 45-60 minutes)

## What You'll Get

A complete **Interview Guide** with:

```markdown
# Interview Guide: [Role] - [Department]
**Prepared for:** [Company Name]
**Interview Duration:** [45-60 minutes]
**Date:** [Date]

---

## Pre-Interview Checklist

- [ ] Review this person's role and responsibilities
- [ ] Review hypotheses being tested (listed below)
- [ ] Prepare recording device (with permission)
- [ ] Set up note-taking (or plan to use /insight-analyzer after)

---

## Hypotheses Being Tested

| # | Hypothesis | Key Question | Signal to Watch For |
|---|-----------|--------------|---------------------|
| 1 | [Hypothesis from scanner] | [Question] | [What would confirm/deny] |
| 2 | [Hypothesis] | [Question] | [Signal] |

---

## Phase 1: Rapport & Scene Setting (5 minutes)

**Goal:** Make them comfortable. Disarm suspicion. Build trust.

**Opening script:**
> "Thanks for making time for this. We're trying to understand how work really
> gets done here — not the org chart version, but the actual day-to-day. We're
> looking for the stuff that's frustrating or time-consuming, so we can figure
> out where AI and automation might actually help. Nothing you say here gets
> attributed to you by name."

**Calibration questions:**
- "How long have you been in this role?"
- "Can you give me the 2-minute version of what your team does?"

**Watch for:** Shoulders dropping, posture relaxing. If they're still tense,
spend more time here. Rushed rapport = guarded answers.

---

## Phase 2: Qualitative Discovery (25-30 minutes)

**Goal:** Understand how they actually work. Follow emotion. Find the real pain.

### Opener
- "Walk me through a typical day or week in your role."

### Pain Point Exploration
[Customized based on role and department]

- "[Role-specific question about their biggest time sink]"
- "[Role-specific question about repetitive tasks]"
- "What task do you dread most?"
- "Where do you spend time that doesn't feel valuable?"
- "What would you do with an extra 5 hours per week?"

### Process Deep-Dives
[Customized based on hypotheses]

- "[Question targeting Hypothesis 1]"
- "[Question targeting Hypothesis 2]"
- "How does [specific process] actually work? Walk me through it step by step."
- "What happens when something goes wrong in that process?"

### Cross-Department Probes
- "Who do you depend on most to get your work done?"
- "Where do things get stuck waiting for someone else?"
- "Is there information you need that's hard to get?"

### Red Flags to Watch For

**You've found something when:**
- Their voice changes (frustration, resignation, excitement)
- They give specific examples ("Like last Tuesday when...")
- They physically show you screens or documents
- They use candid language ("honestly this is garbage")
- They say "I know it's not the right way but..."
- They describe workarounds or unofficial processes

**Follow the emotion.** When they get animated about something, don't move on — dig deeper:
- "Tell me more about that."
- "How often does that happen?"
- "What do you do when that happens?"

---

## Phase 3: Quantitative Validation (10-15 minutes)

**Goal:** Pin down the numbers. These build your business case.

For each pain point identified in Phase 2:

- "How many hours per week does that take?"
- "How many times per [week/month] does this happen?"
- "How many people are involved in this process?"
- "What's the error rate? How often does it need to be redone?"
- "What happens when it goes wrong — what's the cost?"

### Quantification Quick Reference

| Question Pattern | Why It Matters |
|-----------------|----------------|
| "Hours per week on X?" | Direct time burden |
| "How many times per month?" | Frequency × time = annual burden |
| "How many people do this?" | Multiply impact across team |
| "What's the error/rework rate?" | Quality cost, not just time |
| "What happens when it fails?" | Downstream impact, risk |

**Pro tip:** People tend to underestimate routine tasks and overestimate one-time efforts. If someone says "about an hour," gently probe: "Walk me through what that hour looks like — start to finish." Often it's actually 90 minutes to 2 hours.

---

## Phase 4: Wrap & Closure (5 minutes)

**Goal:** Clean exit. Leave the door open.

**Summary check:**
> "Let me make sure I heard you right. The biggest things you mentioned were
> [summary of top 2-3 pain points]. Does that sound right? Anything I missed?"

**Forward-looking:**
- "If you could wave a magic wand and fix one thing about your workflow, what would it be?"
- "Is there anyone else I should talk to about [specific topic they raised]?"

**Close:**
> "This was really helpful. We may follow up with a few clarifying questions —
> is that OK? Thanks for your time."

---

## Post-Interview Actions

1. **Process immediately** — Run `/insight-analyzer` with the transcript or your notes within 24 hours (details fade fast)
2. **Note your gut feelings** — What surprised you? What seemed like a bigger deal than they let on?
3. **Update hypotheses** — Did this confirm, deny, or modify your working theories?
4. **Identify follow-ups** — Who else did they mention? What needs a deeper look?

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help? → https://morningside.ai
```

## Interview Order: The U-Shaped Method

The sequence of interviews matters. Don't just talk to whoever's available first.

```
  Executives          ←── Start here (understand vision + priorities)
       │
       ▼
  Department Heads    ←── Then here (bridge strategy and operations)
       │
       ▼
  Frontline Workers   ←── Go deep (learn how work actually happens)
       │
       ▼
  Department Heads    ←── Validate patterns
       │
       ▼
  Executives          ←── End here (present early findings, calibrate)
```

**Why this works:**
- Starting with executives gives you the strategic context to evaluate what frontline workers tell you
- Frontline interviews reveal the ground truth (executives often don't know the real problems)
- Returning to executives lets you validate findings and build buy-in before the final presentation

## How Many Interviews?

| Company Size | Target Interviews | Coverage |
|-------------|-------------------|----------|
| <50 employees | 8-12 | Most key roles |
| 50-200 employees | 12-18 | Priority departments |
| 200+ employees | 15-25 | Deep dive on 3-4 departments |

## Tips for Better Interviews

- **Record if possible.** Ask permission. Recordings let you focus on listening instead of note-taking, and `/insight-analyzer` can process transcripts directly.
- **Leave 15 minutes between interviews.** Quick notes while context is fresh.
- **Cluster by department.** Context carries over — you'll ask better questions in interview #3 about Finance than #1.
- **Don't sell solutions during the interview.** Your job is to listen and understand, not pitch AI tools. Save solutioning for later.
- **Watch for "the thing behind the thing."** The first problem they mention is rarely the biggest one. The real pain usually comes out 15-20 minutes in, once they trust you.
