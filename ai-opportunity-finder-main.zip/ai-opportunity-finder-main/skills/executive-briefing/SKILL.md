---
name: executive-briefing
description: Create a 7-slide executive presentation outline with talking points, opening hooks, and a recommended path forward. Turns your discovery findings into a concise, action-oriented pitch for leadership. Use after running /priority-ranker to present findings to executives or decision-makers.
argument-hint: "[company-name]"
---

# Executive Briefing Builder

Transforms your prioritized findings into a 7-slide executive presentation outline — the same structure used by professional consultants to present AI discovery findings to C-suite executives. Designed for 20 minutes or less, because executives don't have an hour.

## The Core Principle: Show, Don't Tell

Abstract recommendations create debate. Concrete findings create action.

When you tell an executive "we could automate scheduling," they nod and move on. When you show them that scheduling costs the organization 1,500 hours/year across 6 departments — with direct quotes from their own people — they lean forward and ask "what do we do about this?"

**This presentation should make executives feel the problem before you present the solution.**

## What I Need From You

1. **Priority Matrix** (from `/priority-ranker`)
2. **Key quotes** from interviews (the most emotionally compelling ones)
3. **Quantified findings** (total hours, cost estimates, department impact)
4. **Company name and context**
5. **Audience** (who's in the room — CEO, department heads, board?)

Optional:
- **Prototypes or demos** you've built (if any — this is the most powerful part)
- **Specific concerns** the audience might have

## What You'll Get

A **7-Slide Presentation Outline** with:
- Slide-by-slide content and layout guidance
- Talking points / speaker notes for each slide
- Q&A preparation (the 5 questions they'll definitely ask)
- Timing guide (20 minutes total)

## The 7-Slide Structure

### Why 7 Slides?

Executives have seen too many 40-slide decks. They tune out by slide 8. Seven slides forces you to be clear, concise, and impactful. Everything that doesn't fit in 7 slides goes in a written appendix (which they'll read only if the 7 slides are compelling).

## Output Format

```markdown
# Executive Briefing: AI Discovery Findings
**Company:** [Company Name]
**Presented by:** [Your name/team]
**Date:** [Date]
**Duration:** 20 minutes (7 slides + Q&A)
**Audience:** [Who's in the room]

---

## Slide 1: Opening Hook (2 minutes)

**Headline:** [Compelling statistic or quote]

**Content:**
> "[Most powerful quote from interviews — something that captures the core
> problem in the voice of their own people]"
>
> — [Role, not name], [Department]

**Supporting stat:**
[Biggest quantified finding: "X hours/year" or "$Y cost" or "Z departments affected"]

**Speaker Notes:**
[What to say: Set the tone. This isn't a generic AI pitch — this is specific
findings from talking to THEIR people about THEIR problems. The quote should
make them feel the problem.]

---

## Slide 2: The Mandate (1 minute)

**Headline:** What We Set Out To Do

**Content (3 bullets max):**
- Interviewed [X] people across [Y] departments
- Identified where AI and automation can move the needle
- Prioritized by impact and feasibility

**Speaker Notes:**
[Quick context on scope and methodology. Don't dwell here — they want findings,
not process. 60 seconds maximum.]

---

## Slide 3: What We Found — Key Insights (3 minutes)

**Headline:** [Number] Key Findings

**Content (3-5 insights, each with a number):**

1. **[Finding 1]:** [Quantified insight — "X department spends Y hours/year on Z"]
2. **[Finding 2]:** [Quantified insight]
3. **[Finding 3]:** [Quantified insight]
4. **[Finding 4]:** [Cross-cutting pattern — "This problem affects N departments"]
5. **[Finding 5]:** [Most surprising finding]

**Important:** These are PROBLEMS, not solutions. You're making them feel the
pain before you offer the cure.

**Speaker Notes:**
[Walk through each finding. Pause on the one that's most relevant to whoever
has the most authority in the room. Watch for reactions — if someone leans
forward, spend more time there.]

---

## Slide 4: Priority Opportunities (3 minutes)

**Headline:** Top [5-7] Opportunities Ranked by Impact

**Content (visual priority matrix, not a dense table):**

**Quick Wins (Start Now):**
- [Opportunity 1] — [One-line description + impact]
- [Opportunity 2] — [One-line description + impact]

**Strategic Initiatives (Next Quarter):**
- [Opportunity 3] — [One-line description + impact]
- [Opportunity 4] — [One-line description + impact]

**Longer-Term Bets:**
- [Opportunity 5] — [One-line description + impact]

**Total addressable impact:** [X hours/year | $Y annual value]

**Speaker Notes:**
[Frame as "not everything — just the priorities." Emphasize the sequencing:
quick wins first to build momentum, then strategic. Don't try to explain
every opportunity — let them read the appendix for details.]

---

## Slide 5: [Demo / Deep Dive #1] (3 minutes)

**Headline:** [Opportunity Name] — What This Could Look Like

**Content:**
If you have a prototype or mockup:
- Live demo (preferred) or screenshots
- 30-second problem statement → 2-minute walkthrough → 30-second impact

If no prototype:
- Before/After comparison of the workflow
- Current state (manual, time-consuming) vs future state (automated, fast)
- Specific example with real context from interviews

**Speaker Notes:**
[This is the most important slide. If you can show something — even a rough
mockup — it's 10x more powerful than describing it. "Here's what we heard
from your people. Here's what a solution could look like."]

---

## Slide 6: [Demo / Deep Dive #2] (3 minutes)

**Headline:** [Second Opportunity Name]

**Content:**
[Same structure as Slide 5 — either a demo, mockup, or before/after comparison]

**Speaker Notes:**
[Pick your second-best opportunity. Different department than Slide 5 if possible,
to show breadth of findings.]

---

## Slide 7: Recommended Path Forward (3 minutes)

**Headline:** What We Recommend

**Content:**

**Immediate (Next 2-4 Weeks):**
- [Quick Win 1 with owner and outcome]
- [Quick Win 2 with owner and outcome]

**Near-Term (Months 1-3):**
- [Project 1]
- [Project 2]

**Strategic (Months 3-6):**
- [Initiative 1]

**Clear Call to Action:**
> "[Specific next step — schedule follow-up, approve budget, assign team, etc.]"

**Speaker Notes:**
[End with a specific ask. Don't let this end with "we'll send you the report."
Ask for a decision: "We'd like to start on [Quick Win 1] next week. Can we
get the green light today?"]

---

## Q&A Preparation

### The 5 Questions They'll Ask

**1. "How long would this take to build?"**
> [Prepared answer with ranges for each priority tier]

**2. "What would this cost?"**
> [Prepared answer — frame as investment vs. cost of inaction]

**3. "What data/systems would we need to connect?"**
> [Technical requirements, kept simple]

**4. "Who would own this internally?"**
> [Recommended internal champion for each initiative]

**5. "What's the ROI?"**
> [Frame: "The cost of doing nothing is [X hours/year, $Y]. The investment
> to fix it is [Z]. Payback period is [N months]."]

### Handling Skepticism

**"We've heard this before from consultants."**
> "That's fair. The difference here is we talked to YOUR people, quantified
> YOUR problems, and [showed you / described] what a solution actually looks
> like. This isn't generic — it's specific to your organization."

**"Can't we just use ChatGPT for this?"**
> "For some quick wins, maybe. But the real value isn't the AI tool — it's
> knowing WHICH problems to solve and HOW to redesign the workflow around
> AI. That's what this analysis provides."

**"Our people are too busy for another initiative."**
> "That's exactly the problem. They're spending [X hours/year] on tasks
> that AI could handle. The initiative saves them time — it doesn't add work."

---

## Presentation Tips

- **20 minutes maximum.** If you go over, you've lost them.
- **Rehearse the demos.** A smooth demo builds confidence. A fumbled demo kills it.
- **Lead with quotes from their people.** Third-party evidence from their own team is more persuasive than any statistic.
- **Watch for the "lean-in" moment.** When someone physically leans forward or starts asking questions, you've found what they care about. Spend more time there.
- **End with a specific ask.** "Let's schedule a follow-up next week" is weak. "Can we start on [Quick Win 1] on Monday?" is strong.

---

## What's NOT in the Slides

Everything that didn't make the 7 slides goes in a **written appendix**:
- Full department syntheses
- Complete opportunity list (not just top 5-7)
- Detailed quantification methodology
- Interview summaries (anonymized)
- Technical architecture considerations

The appendix exists for the people who want to dig deeper AFTER the presentation hooks them. Don't present it — reference it.

---

## What Comes After the Presentation

If the presentation lands well, here's what typically happens:

1. **Immediate:** Quick wins get greenlit (often same day)
2. **Within a week:** Budget discussion for strategic initiatives
3. **Within a month:** Build phase begins on top 1-2 priorities

The hard part isn't finding the opportunities — it's executing on them. That requires:
- Technical expertise to build solutions
- Change management to drive adoption
- Ongoing iteration based on user feedback
- Training to ensure people actually use what gets built

This is where most organizations need professional help. Finding the problems is
step 1 (and these skills help you do that). Building and deploying solutions that
people actually adopt is step 2.

---
Built with the AI Opportunity Finder by Morningside AI
Ready for step 2? → https://morningside.ai
```
