---
name: workflow-audit
description: Audit a specific workflow or process to identify AI and automation opportunities. Walks you through mapping how work actually gets done, where time is wasted, and what could be automated. Use when you want to analyze a department process, map a workflow, or find bottlenecks that AI could fix.
argument-hint: "[department-or-process-name]"
---

# Workflow Audit

Guides you through a structured audit of a specific workflow or business process to identify exactly where AI and automation could save time, reduce errors, or improve quality. This turns the abstract ("find AI opportunities") into the concrete ("here's where 15 hours/week is being wasted").

## How It Works

I'll walk you through a series of questions about how a specific process works today. You describe the reality — I map the workflow, flag the pain points, and score the automation opportunities.

This is an **interactive skill**. I'll ask questions in phases, then produce a structured audit report.

## What I Need From You

To start, provide:
1. **Department or function** (e.g., "Sales", "Operations", "Finance", "HR")
2. **The specific process to audit** (e.g., "monthly reporting", "customer onboarding", "invoice processing")
3. **Who's involved** (roles, not necessarily names)

I'll then ask follow-up questions in three phases.

## The Audit Process

### Phase 1: Process Mapping (5-10 questions)

I'll ask you to walk me through the process step by step:
- "What triggers this process? How does it start?"
- "What happens next? Who does what?"
- "What tools or systems are used at each step?"
- "Where does information get passed between people?"
- "How does this process end? What's the final output?"

**Goal:** Map the actual workflow as it exists today — not the org chart version, but how it really works.

### Phase 2: Pain Point Identification (5-8 questions)

Now I'll probe for problems:
- "Which step takes the most time?"
- "Where do errors or rework happen most often?"
- "What's the most frustrating part of this process?"
- "Are there any workarounds people use to get around the official process?"
- "What happens when [key person] is out sick or on vacation?"
- "How many hours per week/month does this process consume?"

**Goal:** Quantify the pain. Get specific numbers — hours, frequency, error rates.

### Phase 3: Automation Assessment (3-5 questions)

Finally, I'll assess what's automatable:
- "Which steps involve moving information between systems?"
- "Which steps require judgment vs. which are repetitive?"
- "What data is available digitally vs. what's in people's heads?"
- "Have you tried any tools or automations for this before?"

**Goal:** Identify which parts of the workflow are candidates for AI/automation.

## What You'll Get

A **Workflow Audit Report** with:

```markdown
# Workflow Audit: [Process Name]
**Department:** [Department]
**Date:** [Date]
**People Involved:** [Roles]

---

## Process Map

### Current Workflow (As-Is)
| Step | Action | Owner | Tool/System | Time | Type |
|------|--------|-------|-------------|------|------|
| 1 | [Action] | [Role] | [Tool] | [Time] | Manual/Semi-Auto/Auto |
| 2 | [Action] | [Role] | [Tool] | [Time] | Manual/Semi-Auto/Auto |
| ... | | | | | |

**Total Process Time:** [X hours per cycle]
**Frequency:** [How often this runs]
**Annual Time Burden:** [Hours/year]

---

## Pain Points Identified

### Pain Point 1: [Title]
- **What's happening:** [Description]
- **Time impact:** [Hours/week or month]
- **Error rate:** [If applicable]
- **Root cause:** [Why this exists]
- **Automation potential:** [High/Medium/Low]

### Pain Point 2: [Title]
...

---

## Automation Opportunities

### Opportunity 1: [Title]
- **What to automate:** [Specific steps from the process map]
- **AI/Automation approach:** [What technology would help]
- **Expected impact:** [Time saved, errors reduced]
- **Complexity:** [Low/Medium/High]
- **Prerequisites:** [What needs to be true for this to work]

| Criteria | Rating |
|----------|--------|
| Impact | [High/Medium/Low] |
| Feasibility | [High/Medium/Low] |
| Quick Win? | [Yes/No] |
| Data Available? | [Yes/No/Partial] |

### Opportunity 2: [Title]
...

---

## Workflow Redesign Sketch

### Proposed Future State
| Step | Action | Owner | Tool/System | Time | Change |
|------|--------|-------|-------------|------|--------|
| 1 | [Action] | [Role/AI] | [Tool] | [Time] | [New/Modified/Unchanged] |
| ... | | | | | |

**Projected Time Savings:** [X hours per cycle → Y hours saved]
**Annual Savings:** [Hours/year] (~$[Amount] at $50/hour)

---

## Priority Recommendation

Based on this audit:
1. **Start here:** [Highest impact, lowest complexity opportunity]
2. **Then:** [Next priority]
3. **Strategic:** [Bigger opportunity requiring more investment]

---

## Next Steps
1. Run `/interview-builder` to create interview guides for the people involved in this process
2. Run `/opportunity-scanner` to generate hypotheses across other departments
3. After multiple audits, run `/priority-ranker` to compare opportunities

---
Built with the AI Opportunity Finder by Morningside AI
Want expert help? → https://morningside.ai
```

## Automation Scoring Framework

I score each opportunity on two dimensions:

**Impact (How much does this matter?)**
- **High:** >1,000 hours/year saved OR >$50K annual value OR affects 5+ people
- **Medium:** 500-1,000 hours/year OR $25-50K OR affects 2-4 people
- **Low:** <500 hours/year OR <$25K OR affects 1 person

**Feasibility (How hard is this to build?)**
- **High:** Can be built in 2-8 weeks with existing tools/data
- **Medium:** 2-3 months, may need integrations or data cleanup
- **Low:** 3+ months, requires significant infrastructure or change management

**The magic quadrant:**

|  | Low Feasibility | High Feasibility |
|--|-----------------|------------------|
| **High Impact** | Strategic (do later) | **Do This First** |
| **Low Impact** | Skip | Quick Win (nice to have) |

## Tips for Best Results

- **Describe reality, not the ideal.** I need to know how things actually work — including the messy workarounds and unofficial processes.
- **Be honest about time.** It's tempting to underestimate. If something "takes about an hour," it probably takes 90 minutes with interruptions.
- **Include the handoffs.** Often the biggest waste isn't in the task itself but in the waiting, coordination, and back-and-forth between people.
- **Don't forget the exceptions.** The "normal" process might be fine — it's the edge cases and exceptions that eat time.
