# The Discovery Sprint Methodology

*A condensed overview of the approach behind the AI Opportunity Finder skills.*

---

## What Is a Discovery Sprint?

A Discovery Sprint is a time-boxed, hypothesis-driven approach to identifying AI and automation opportunities within an organization. Rather than attempting to document every process comprehensively, you go "mile-wide, inch-deep" — surveying the landscape quickly, then drilling down only on what matters most.

**Core characteristics:**
- **Duration:** 2 weeks (10 business days)
- **Approach:** Hypothesis-driven, not comprehensive
- **Output:** 5-8 prioritized opportunities with quantified impact
- **Deliverable:** Executive-ready presentation with concrete findings

---

## Why This Beats Traditional Assessments

Traditional approaches fail for predictable reasons:

| Traditional Assessment | Discovery Sprint |
|----------------------|-----------------|
| 3-6 months | 2 weeks |
| Document everything | Prioritize ruthlessly |
| 50-page report | 7-slide presentation |
| Abstract recommendations | Quantified findings + direct quotes |
| No urgency to act | Built-in momentum |

The sprint approach works because:
1. **Forced prioritization** — Limited time forces focus on what matters
2. **Fresh findings** — Two weeks means insights are immediately actionable
3. **Concrete evidence** — Stakeholders hear their own people's words, not consultant jargon
4. **Built-in momentum** — Speed creates urgency to act

---

## The Five Stages

```
RESEARCH → KICKOFF → INTERVIEWS → SYNTHESIS → DELIVERY
Week -2     Day 1    Days 2-7    Days 8-10   Days 11-14
```

### Stage 1: Research (Pre-Sprint)

**Goal:** Develop hypotheses before you start.

Don't go in blind. Before the sprint:
- Develop 3-5 hypotheses about where the biggest opportunities exist
- Deploy a short survey to quantify pain points
- Schedule interviews using the U-shaped method
- Review industry patterns relevant to this organization

**The 7 skills start here:** `/opportunity-scanner` generates your initial hypotheses.

### Stage 2: Kickoff (Day 1)

**Goal:** Align with leadership on priorities and get access.

- Morning: Kickoff meeting with leadership (confirm priorities)
- Afternoon: Facility tour / system access / shadow key workflows
- Evening: Review survey data, finalize interview schedule

### Stage 3: Interviews (Days 2-7)

**Goal:** Talk to the people who do the actual work.

**The U-Shaped Method:**

```
  Executives (Days 1-2)     Start with strategic context
       │
       ▼
  Frontline (Days 3-7)      Go deep on how work really happens
       │
       ▼
  Executives (Days 8-10)    Return with findings to validate
```

**Why this sequence:**
- Executives give you the strategic context to evaluate what frontline workers tell you
- Frontline workers reveal the ground truth (executives often don't know the real problems)
- Returning to executives validates findings and builds buy-in before the final presentation

**The 4-Phase Interview:**

| Phase | Duration | Goal |
|-------|----------|------|
| 1. Rapport | 5 min | Build trust, disarm suspicion |
| 2. Qualitative Discovery | 25-30 min | Follow emotion, find the real pain |
| 3. Quantitative Validation | 10-15 min | Pin down the numbers |
| 4. Wrap | 5 min | Summarize, identify follow-ups |

**The skills help here:** `/interview-builder` creates the interview guide. `/insight-analyzer` processes each transcript.

### Stage 4: Synthesis (Days 8-10)

**Goal:** Turn individual findings into organizational insights.

This is where the magic happens. Individual interviews are data points. Synthesis reveals patterns.

**The 3-Tier Processing System:**

```
Tier 1: Individual Findings      One doc per interview
           │
           ▼
Tier 2: Department Synthesis      One doc per department
           │
           ▼
Tier 3: Master Findings           One doc for the whole organization
```

**What you're looking for:**
- Pain points mentioned by 2+ people → validated organizational problem
- Patterns that span departments → systemic opportunity
- The gap between what executives think and what frontline reports → the real story

**The skills handle this:** `/department-synthesizer` does Tier 2. `/priority-ranker` does Tier 3.

### Stage 5: Delivery (Days 11-14)

**Goal:** Present findings in a way that drives action.

**The 7-Slide Structure:**

| Slide | Content | Time |
|-------|---------|------|
| 1 | Opening hook — most compelling quote or statistic | 2 min |
| 2 | The mandate — what you set out to do | 1 min |
| 3 | Key findings — problems, not solutions | 3 min |
| 4 | Priority opportunities — ranked by impact | 3 min |
| 5 | Deep dive #1 — demo or before/after | 3 min |
| 6 | Deep dive #2 — demo or before/after | 3 min |
| 7 | Recommended path forward — specific next steps | 3 min |

**The key insight:** Show, don't tell. A working prototype or concrete before/after comparison is 10x more persuasive than a bullet point recommendation.

**The skills finish here:** `/executive-briefing` builds the presentation outline.

---

## Common Patterns You'll Find

Across dozens of Discovery Sprints, these patterns appear repeatedly:

### 1. Data Without Insights ("Death by Tables")
Organizations invest in data systems but lack the synthesis layer to turn data into actionable intelligence. Staff drown in raw tables.

### 2. Manual Scheduling Cascade
One person's schedule changes trigger hours of manual updates across multiple departments. No automated propagation.

### 3. Report Assembly Line
The same information reformatted for different audiences, each requiring manual work.

### 4. Institutional Knowledge in Heads
Critical processes depend on specific people's memory. Creates single points of failure.

### 5. Communication Silos
Information flows through personal relationships, not systems. Creates gaps and inconsistencies.

### 6. Analytics Capacity Crunch
Central analytics team is too small to serve all departments. Becomes the bottleneck for everyone.

### 7. Text/Email as System of Record
Critical operational information lives in messages, not structured systems.

---

## Prioritization Framework

### The Impact × Feasibility Matrix

|  | Low Feasibility | High Feasibility |
|--|-----------------|------------------|
| **High Impact** | Strategic (plan for later) | **Do This First** |
| **Low Impact** | Skip entirely | Quick Win (nice momentum) |

### The Executive Test

For every opportunity, ask: "Would the CEO immediately understand why this matters?"

If the answer requires explanation → deprioritize.

### The Sequence

1. **Quick wins first** — Build credibility with visible, achievable results
2. **Strategic next** — Use quick win momentum to fund bigger bets
3. **Always balance** — Quick wins create momentum; strategic initiatives create lasting value

---

## Tips for Running Your Own Sprint

1. **Get a champion.** You need someone inside the organization who will open doors, gut-check your findings, and tell you when you're going down the wrong path.

2. **Follow the emotion.** When someone gets frustrated, excited, or resigned during an interview — dig deeper. That's where the real pain is.

3. **Quantify everything.** "It takes a long time" isn't useful. "It takes 3 hours per week, 50 weeks per year, across 4 people = 600 hours/year" is powerful.

4. **Be willing to pivot.** Your initial hypotheses will be wrong — that's the point. Better to discover this on Day 4 than Day 14.

5. **Present findings, not recommendations.** Executives trust evidence from their own people more than consultant recommendations. Lead with quotes and numbers, not opinions.

---

## Learn More

This methodology was developed by [Morningside AI](https://morningside.ai) across dozens of Discovery Sprint engagements for organizations ranging from major sports franchises to healthcare systems to manufacturing companies.

If you want to learn more about the approach, or want professional help running a Discovery Sprint for your organization, visit [morningside.ai](https://morningside.ai).

---

*Built by [Morningside AI](https://morningside.ai) — AI Strategy & Transformation for Growing Companies*
