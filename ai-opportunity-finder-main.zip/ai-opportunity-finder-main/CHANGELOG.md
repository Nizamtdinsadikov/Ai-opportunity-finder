# Changelog

## [1.0.0] - 2026-02-10

### Added
- Initial release of the AI Opportunity Finder skills pack
- 7 Claude skills: opportunity-scanner, workflow-audit, interview-builder, insight-analyzer, department-synthesizer, priority-ranker, executive-briefing
- 5 blank templates for each stage of the workflow
- 4 anonymized examples from a real Discovery Sprint engagement
- README with installation guide and workflow documentation
- METHODOLOGY.md with condensed Discovery Sprint methodology overview
- Plugin manifest for Claude Code plugin installation
